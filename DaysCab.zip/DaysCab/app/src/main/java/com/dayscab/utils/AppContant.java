package com.dayscab.utils;

public interface AppContant {

    String TYPE = "type";
    String USER = "USER";
    String DRIVER = "DRIVER";

}
