package com.dayscab.utils;

public interface RequestDialogCallBackInterface {
    void bookingApiCalled();
}
